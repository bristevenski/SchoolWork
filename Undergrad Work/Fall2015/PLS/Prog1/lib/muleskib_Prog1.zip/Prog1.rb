# This is the main for Prog1.
# It invokes the run method of a Vectorator instance
# Author:: Dr. Clifton, modified by Dr. Tian

require_relative 'Vectorator'

#$stdin.reopen("p1.in")

Vectorator.new.run
