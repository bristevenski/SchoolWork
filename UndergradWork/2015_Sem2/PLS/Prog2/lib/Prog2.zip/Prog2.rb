# This is the main for Prog2.
# It invokes the run method of a Tokenizer instance
# Author:: Dr. Clifton, modified by B Tian

require_relative "Tokenizer.rb"

# Be sure to comment it out when you submit to the GRADER.
#$stdin.reopen("p2.in")
# $stdin.reopen("Prog2.in")

Tokenizer.new.run

puts "Done"


